﻿using System;

class DataDetalhada
{
    static void Main(string[] args)
    {
        Console.WriteLine("Escolha um formato para exibir a data atual:");
        Console.WriteLine("1. Formato completo");
        Console.WriteLine("2. Apenas a data no formato \"01/03/2024\"");
        Console.WriteLine("3. Apenas a hora no formato de 24 horas");
        Console.WriteLine("4. A data com o mês por extenso");
        Console.Write("Opção: ");

        int escolha;
        if (int.TryParse(Console.ReadLine(), out escolha))
        {
            switch (escolha)
            {
                case 1:
                    DataToda();
                    break;
                case 2:
                    ApenasData();
                    break;
                case 3:
                    ApenasHora();
                    break;
                case 4:
                    DataComMes();
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }
        }
        else
        {
            Console.WriteLine("Opção inválida.");
        }
    }

    static void DataToda()
    {
        DateTime dataAtual = DateTime.Now;
        Console.WriteLine($"Data completa: {dataAtual}");
    }

    static void ApenasData()
    {
        DateTime dataAtual = DateTime.Now;
        Console.WriteLine($"Apenas a data: {dataAtual.ToShortDateString()}");
    }

    static void ApenasHora()
    {
        DateTime dataAtual = DateTime.Now;
        Console.WriteLine($"Apenas a hora: {dataAtual.ToString("HH:mm:ss")}");
    }

    static void DataComMes()
    {
        DateTime dataAtual = DateTime.Now;
        string mesExtenso = dataAtual.ToString("dd MMMM yyyy");
        Console.WriteLine($"Data com o mês por extenso: {mesExtenso}");
    }
}