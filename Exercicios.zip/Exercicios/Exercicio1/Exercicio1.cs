﻿namespace BoasVindas;

public class Saudacao
{
    public static void Main()
    {
        Console.WriteLine("Nome: ");
        string nome = Console.ReadLine();
        Console.WriteLine("Olá, " + nome + "! Seja muito bem-vindo!");
    }
}