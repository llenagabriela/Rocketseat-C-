﻿namespace Nome;

public class Nome
{
    public static void Main()
    {
        Console.WriteLine("Nome: ");
        string nome = Console.ReadLine();
        Console.WriteLine("Sobrenome: ");
        string sobrenome = Console.ReadLine();
        Console.WriteLine(nome + " " + sobrenome);
    }
}